All Rcbot's DLL files go in this folder.

rcbot.dll
rcbot_i486.so
rcbot_mm.dll
rcbot_mm_i486.so